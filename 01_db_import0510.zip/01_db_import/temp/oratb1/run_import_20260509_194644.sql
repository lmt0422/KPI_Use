SET VERIFY OFF
SET FEEDBACK OFF
@"D:\project_all\unmasked\01_db_import\tool\oratb1\..\..\tool\oratb1\sql\import.sql" "IMP_20260509_194644" "dummy_value" "REPLACE" "1" "ORACLE1-" "import_ORACLE1-_rds_20260509_194644.log"
EXIT
