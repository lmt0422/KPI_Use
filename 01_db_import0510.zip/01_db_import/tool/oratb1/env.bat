@echo off
setlocal

REM ==========================================================
REM ���؂�ւ��X�C�b�` (1: ���[�J��Docker��, 0: AWS RDS��)
REM ==========================================================
SET "IS_TEST=1"

REM 01_exec_import.ps1�����01_dmp_import_oratb1.bat�Ŏg�p������ϐ���ݒ�
set "BASE_DIR=%~dp0..\.."
set "ORATBX=oratb1"

IF "%IS_TEST%"=="1" (
    REM ------------------------------------------------------
    REM ���[�J���e�X�g���ݒ� (Docker Oracle 23ai)
    REM ------------------------------------------------------
    set "U5_S3EXPIMPBKT=my-local-test-bucket"
    set "LOGIN_INFO=127.0.0.1:1521/FREEPDB1"
    set "DUMP_DIR_NAME=DATA_PUMP_DIR"
    
    set "schema_oratb1=orausr00"
    set "user_info_orausr00=ORAUSR00/ORAUSR00"
    
    REM 【新規追加】Docker環境での文字化け防止
    set "LOCAL_SYS_PWD=12345678" 
    set "NLS_LANG=Japanese_Japan.JA16SJISTILDE"
    ) ELSE (
    REM ------------------------------------------------------
    REM AWS本番環境設定 (AWS RDS for Oracle)
    REM ------------------------------------------------------
    set "U5_S3EXPIMPBKT=value-prod-s3-tokyo-tempbucket"
    set "LOGIN_INFO=value-prod-restore-db-01.prd.lvcl.jp:1521/oratb4"
    set "DUMP_DIR_NAME=DATA_PUMP_DIR"

    set "schema_oratb1=orausr00"
    set "user_info_orausr00=ORAUSR00/ORAUSR00"
    set "NLS_LANG=Japanese_Japan.JA16SJISTILDE"
    )

    REM 各パスの設定
    set "SOURCE_DIR=%BASE_DIR%\tool\%ORATBX%"
    set "BAT_LOG_DIR_NAME=%BASE_DIR%\logs\%ORATBX%\import_dmp"
    set "TEMP_LOG_DIR_NAME=%BASE_DIR%\temp\%ORATBX%"
    set "WINDOWS_DUMP_DIR_NAME=%BASE_DIR%\data\import\%ORATBX%"
    set "S3_RDSLOG_DIR_NAME=ikou/db_kizon/logs/import"
    set "CONFFILE_DIR_NAME=%BASE_DIR%\conf\%ORATBX%"

    set "S3_TRANSFER_INTERVAL_TIMER=5"
    set "S3_TRANSFER_TIMEOUT_SEC=0"
    set "logoutputpath=%~dp0..\..\logs"

    REM 呼び出し先で変数を利用可能にするための処理
    endlocal & (
    set "IS_TEST=%IS_TEST%"
    set "ORATBX=%ORATBX%"
    set "U5_S3EXPIMPBKT=%U5_S3EXPIMPBKT%"
    set "LOGIN_INFO=%LOGIN_INFO%"
    set "SOURCE_DIR=%SOURCE_DIR%"
    set "DUMP_DIR_NAME=%DUMP_DIR_NAME%"
    set "BAT_LOG_DIR_NAME=%BAT_LOG_DIR_NAME%"
    set "TEMP_LOG_DIR_NAME=%TEMP_LOG_DIR_NAME%"
    set "CONFFILE_DIR_NAME=%CONFFILE_DIR_NAME%"
    set "schema_oratb1=%schema_oratb1%"
    set "user_info_orausr00=%user_info_orausr00%"
    set "NLS_LANG=%NLS_LANG%"
    )
