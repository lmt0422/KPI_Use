# 1.1 INIT
$CMDNAME = $MyInvocation.MyCommand.Name -replace '\.ps1$', ''

# 1.1.2 ARGS
$DUMPFILE_NAME = $args[0]
$TABLE_NAME = $args[1]
$SCHEMA_NAME = $args[2]
$TAG = $args[3]

# VARS
$TIMESTAMP = Get-Date -Format "yyyyMMdd_HHmmss"
$DP_FILENAME = "${DUMPFILE_NAME}%U.dmp"
$RDS_LOGFILE_NAME = "import_${DUMPFILE_NAME}_rds_${TIMESTAMP}.log"
$BAT_LOGFILE_NAME = "import_${DUMPFILE_NAME}_bat_${TIMESTAMP}.log"
$BAT_LOGFILE_PATH = "${Env:BAT_LOG_DIR_NAME}\${BAT_LOGFILE_NAME}"
$JOB_NAME = "IMPJOB" + (Get-Date -Format "HHmmss")
$TABLE_EXISTS_ACTION = "REPLACE"
$INCLUDE_METADATA = 1
$SQL_FILE_PATH = "${Env:SOURCE_DIR}\sql"
$DBMS_OUTPUT = "${Env:TEMP_LOG_DIR_NAME}\TEMP_${DUMPFILE_NAME}_${TIMESTAMP}.txt"

# 2.0.1 NORMAL EXIT
function NORMAL {
    if (Test-Path "$DBMS_OUTPUT") {
        Write-Output "INFO : Outputting RDS temporary log to batch log." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
        Get-Content -Path "$DBMS_OUTPUT" | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
        Remove-Item "$DBMS_OUTPUT"
    }
    exit 0
}

# 2.1.1 ABNORMAL EXIT
function ABNORMAL {
    if (Test-Path "$DBMS_OUTPUT") {
        Write-Output "INFO : Outputting RDS temporary log to batch log." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
        Get-Content "$DBMS_OUTPUT" | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
        Remove-Item "$DBMS_OUTPUT"
    }
    $ERROR_FILE = "${Env:TEMP_LOG_DIR_NAME}\ABNORMAL_END_${TAG}_${TIMESTAMP}.txt"
    Write-Output "ERROR : Dump: ${DUMPFILE_NAME} STEP: ${JOB_STEP} Failed." | Out-File "$ERROR_FILE" -Encoding default
    exit 99
}

# ARGS CHECK
if ($args.Count -ne 4) {
    Write-Output "ERROR : $CMDNAME missing arguments." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
    ABNORMAL
}

# 1.3 S3 Download
$JOB_STEP = "1.3 S3 Download"
if ($Env:IS_TEST -eq "1") {
    # DOCKER SIMULATION: Copy from mounted vol to PDB DATA_PUMP_DIR
    Write-Output "INFO : [DOCKER] Simulating S3 download (Copying files to RDS folder)..." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
    
    $PDB_DUMP_PATH = "/opt/oracle/admin/FREE/dpdump/514EB90F74C70D2DE063020012ACAFD4"
    $DOCKER_CMD = "rm -f ${PDB_DUMP_PATH}/*.dmp; " +
                  "cp /opt/oracle/oradata/dpdump/${DUMPFILE_NAME}*.dmp ${PDB_DUMP_PATH}/; " +
                  "chown oracle:dba ${PDB_DUMP_PATH}/*.dmp"
                  
    docker exec rds-mock bash -c "$DOCKER_CMD"
    if ($LASTEXITCODE -ne 0) {
        Write-Output "ERROR : [DOCKER] S3 download simulation failed." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
        ABNORMAL
    }
} else {
    # AWS REAL S3 DOWNLOAD
    $S3_SQL = "${SQL_FILE_PATH}\s3_download.sql"
    & sqlplus -S "$SCHEMA_NAME/$SCHEMA_NAME@$Env:LOGIN_INFO" "@$S3_SQL" "$Env:U5_S3EXPIMPBKT" "$Env:DUMP_DIR_NAME" "$DUMPFILE_NAME" | Out-File "$DBMS_OUTPUT" -Encoding default
    if ($LASTEXITCODE -ne 0) {
        Write-Output "ERROR : S3 Download failed." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
        ABNORMAL
    }
}

# 1.4 Import
$JOB_STEP = "1.4 Import Execution"
Write-Output "INFO : Starting Import. (File: $DP_FILENAME)" | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
$IMPORT_SQL = "${SQL_FILE_PATH}\import.sql"
$DB_CONN = "$SCHEMA_NAME/$SCHEMA_NAME@$Env:LOGIN_INFO"
& sqlplus -S "$DB_CONN" "@$IMPORT_SQL" "$JOB_NAME" "$TABLE_NAME" "$TABLE_EXISTS_ACTION" "$INCLUDE_METADATA" "$DP_FILENAME" "$RDS_LOGFILE_NAME" | Out-File "$DBMS_OUTPUT" -Encoding default
if ($LASTEXITCODE -ne 0) {
    Write-Output "ERROR : Import SQL failed. (ExitCode: $LASTEXITCODE)" | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
    ABNORMAL
}
Write-Output "INFO : Import SQL finished successfully." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default

# 1.7 Fetch RDS Log
$JOB_STEP = "1.7 Fetch RDS Log"
Write-Output "INFO : Fetching RDS log to local folder." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
$LOCAL_RDS_LOG_PATH = "${Env:BAT_LOG_DIR_NAME}\${RDS_LOGFILE_NAME}"

if ($Env:IS_TEST -eq "1") {
    $DOCKER_LOG_PATH = "/opt/oracle/admin/FREE/dpdump/514EB90F74C70D2DE063020012ACAFD4/${RDS_LOGFILE_NAME}"
    docker cp "rds-mock:${DOCKER_LOG_PATH}" "$LOCAL_RDS_LOG_PATH"
} else {
    $SQL_READ_LOG = "set pagesize 0 linesize 2000 trimspool on feedback off echo off`n" +
                    "select text from table(rdsadmin.rds_file_util.read_text_file('DATA_PUMP_DIR', '${RDS_LOGFILE_NAME}'));`n" +
                    "exit;"
    $SQL_READ_LOG | sqlplus -S "$DB_CONN" | Out-File "$LOCAL_RDS_LOG_PATH" -Encoding default
}

# 1.8 RDS File Cleanup
$JOB_STEP = "1.8 RDS File Cleanup"
Write-Output "INFO : Starting RDS file cleanup." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
$DEL_SQL = "${SQL_FILE_PATH}\fremove_rds_file_2.sql"
& sqlplus -S "$SCHEMA_NAME/$SCHEMA_NAME@$Env:LOGIN_INFO" "@$DEL_SQL" "$DUMPFILE_NAME" "$RDS_LOGFILE_NAME" | Out-File "$DBMS_OUTPUT" -Encoding default
if ($LASTEXITCODE -ne 0) {
    Write-Output "ERROR : RDS file cleanup failed." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default
    ABNORMAL
}
Write-Output "INFO : RDS file cleanup completed." | Out-File "$BAT_LOGFILE_PATH" -Append -Encoding default

# 1.9 END
NORMAL
