@echo off
setlocal enabledelayedexpansion
echo [INFO] Starting 01_dmp_import_oratb1-1.bat...
set "ENVBAT_PATH=%~dp0env.bat"
call "%ENVBAT_PATH%"
if %ERRORLEVEL% neq 0 (
    echo [ERROR] env.bat load failed.
    exit /b 99
)
set "FILENAME=%~nx0"
set "NAME1=%FILENAME:01_dmp_import_=%"
set "TAG=%NAME1:.bat=%"
set "CONF_FILE_NAME=01_dmp_import_%TAG%.conf"
set "IMPORT_BAT_NAME=%~dp001_exec_import.ps1"
if not exist "%CONFFILE_DIR_NAME%\%CONF_FILE_NAME%" (
    echo [ERROR] Config not found: %CONFFILE_DIR_NAME%\%CONF_FILE_NAME%
    exit /b 1
)
echo [INFO] Starting import loops...
for /f "usebackq tokens=1,2,3 delims= " %%A in ("%CONFFILE_DIR_NAME%\%CONF_FILE_NAME%") do (
    echo [INFO] Executing: %%A %%B %%C
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%IMPORT_BAT_NAME%" %%A %%B %%C %TAG%
)
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Import batch failed.
    exit /b 1
)
echo [INFO] All tasks completed successfully.
exit /b 0