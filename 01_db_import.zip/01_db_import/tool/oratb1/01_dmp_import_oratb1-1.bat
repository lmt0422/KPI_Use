@echo off
chcp 932 >nul
setlocal enabledelayedexpansion

REM 1.1. 変数設定
set "IMPORT_MODE=%~1"
if "%IMPORT_MODE%"=="" set "IMPORT_MODE=REPLACE"
echo 実行モード : %IMPORT_MODE%

REM 1.1.1. 変数の設定
REM 環境変数ファイル読み込み
set "ENVBAT_PATH=%~dp0env.bat"
call %ENVBAT_PATH%

if %ERRORLEVEL% neq 0 (
    echo ERROR : 環境情報ファイルの読み込みに失敗しました。
    echo 全処理終了 (異常終了)
    exit /b 99
)

REM 変数を設定
set "FILENAME=%~nx0"
set "NAME1=%FILENAME:01_dmp_import_=%"
set "TAG=%NAME1:.bat=%"

REM 全DB復旧モードのため並列数は 1 に制限することを推奨
REM (ps1側でPARALLEL=8を指定しているため、bat側で複数並列させると資源が枯渇します)
set "MAX_PARALLEL=1"
set "PSI_COUNT=0"
set "COUNT_PS1_TAG=%TAG%"
set "CONFFILE_LENGTH=0"
set "EXEC_COUNT=0"
set "CONF_FILE_COL_COUNT=0"
set "CONF_FILE_NAME=01_dmp_import_%TAG%.conf"
set "TEMP_ABNORMAL_LOG_PATH=%TEMP_LOG_DIR_NAME%\ABNORMAL_END_%TAG%_*.txt"

set "IMPORT_BAT_NAME=%~dp001_exec_import.ps1"

REM 日付 (yyyyMMdd) と時刻 (HHmmss) を取得
for /f "tokens=1-4 delims=/ " %%a in ('date /t') do (
    set YYYY=%%a
    set MM=%%b
    set DD=%%c
)

for /f "tokens=1-3 delims=:." %%a in ("%TIME%") do (
    set HH=%%a
    set MI=%%b
    set SS=%%c
)

REM ログファイル名を設定
set "ERROR_LOG_PATH=%BAT_LOG_DIR_NAME%\..\ERROR_LOG_%TAG%_%YYYY%%MM%%DD%_%HH%%MI%%SS%.log"
set "BAT_LOG_PATH=%BAT_LOG_DIR_NAME%\..\DMP_IMPORT_%TAG%_BAT_%YYYY%%MM%%DD%_%HH%%MI%%SS%.log"

REM 2.1. dmpファイルインポート対象の設定ファイルのチェック
if not exist "%CONFFILE_DIR_NAME%\%CONF_FILE_NAME%" (
    echo ERROR : dmpファイルインポート対象の設定ファイルが存在しません。>> %ERROR_LOG_PATH%
    echo ERROR : [設定ファイル名 : %CONF_FILE_NAME% ] >> %ERROR_LOG_PATH%
    goto ABNORMAL
)

REM 2.1.2. 設定ファイルの行数チェック
for /f "usebackq tokens=*" %%L in ("%CONFFILE_DIR_NAME%\%CONF_FILE_NAME%") do (
    set /a CONFFILE_LENGTH+=1
)

REM 2.2. インポートバッチの非同期並列実行処理
for /f "usebackq tokens=1,2,3 delims= " %%A in ("%CONFFILE_DIR_NAME%\%CONF_FILE_NAME%") do (
    set /a CONF_FILE_COL_COUNT+=1
    set "HAS_CONFIG_ERROR=0"

    if "%%A"=="" set "HAS_CONFIG_ERROR=1"
    if "%%B"=="" set "HAS_CONFIG_ERROR=1"
    if "%%C"=="" set "HAS_CONFIG_ERROR=1"

    if "!HAS_CONFIG_ERROR!"=="0" (
        set /a EXEC_COUNT+=1

        REM 並列数が上限未満になるまで待機 (全DB復旧では通常1回のみ)
        set "CAN_START=0"
        for /L %%W in (1,1,3600) do (
            if "!CAN_START!"=="0" (
                set "PSI_COUNT=0"
                for /f "skip=1 tokens=*" %%P in ('wmic process where "name='powershell.exe'" get CommandLine') do (
                    echo %%P | findstr /i /c:"%IMPORT_BAT_NAME%" | findstr /c:"%COUNT_PS1_TAG%" >nul
                    if not errorlevel 1 set /a PSI_COUNT+=1
                )

                if !PSI_COUNT! lss %MAX_PARALLEL% (
                    set "CAN_START=1"
                ) else (
                    timeout /t 5 >nul
                )
            )
        )

        echo ダンプファイル接頭辞 : %%A のインポートを開始します。 >> %BAT_LOG_PATH%
        start /B "" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%IMPORT_BAT_NAME%" %%A %%B %%C %COUNT_PS1_TAG% %IMPORT_MODE%
        timeout /t 2 >nul
    )
)

REM 2.2.3. インポートバッチの終了待機
set "ALL_DONE=0"
for /L %%W in (1,1,3600) do (
    if "!ALL_DONE!"=="0" (
        set "PSI_COUNT=0"
        for /f "skip=1 tokens=*" %%P in ('wmic process where "name='powershell.exe'" get CommandLine') do (
            echo %%P | findstr /i /c:"%IMPORT_BAT_NAME%" | findstr /c:"%COUNT_PS1_TAG%" >nul
            if not errorlevel 1 set /a PSI_COUNT+=1
        )

        if !PSI_COUNT! equ 0 (
            set "ALL_DONE=1"
        ) else (
            echo インポート完了待機中... (%TAG%) >> %BAT_LOG_PATH%
            timeout /t 10 >nul
        )
    )
)

REM 2.3. インポートバッチの実行結果の確認
if exist %TEMP_ABNORMAL_LOG_PATH% (
    for %%f in (%TEMP_ABNORMAL_LOG_PATH%) do (
        type "%%f" >> "%ERROR_LOG_PATH%"
    )
    del %TEMP_ABNORMAL_LOG_PATH%
    goto ABNORMAL
)

if %CONFFILE_LENGTH% neq %EXEC_COUNT% (
    echo ERROR : 設定ファイルの処理件数不一致。 >> %ERROR_LOG_PATH%
    goto ABNORMAL
)

:NORMAL
echo 全処理終了 (正常終了) >> %BAT_LOG_PATH%
exit /b 0

:ABNORMAL
echo 全処理終了 (異常終了) >> %ERROR_LOG_PATH%
exit /b 1