# ==========================================================
# 01_exec_import.ps1
# Data Pump Import Execution Script (RDS Oracle)
# ==========================================================

# 1.1 初期化
$CMDNAME = $MyInvocation.MyCommand.Name -replace '\.ps1$', ''

# 1.1.2 引数の取得
$DUMPFILE_NAME=$args[0] # "oracle1-" などの接頭辞
$TABLE_NAME=$args[1]    # 削除/インポート対象のスキーマ名 (confの2列目)
$SCHEMA_NAME=$args[2]   # (予約用)
$TAG=$args[3]
$IMPORT_MODE=$args[4]   # CLEANUP または REPLACE

# デフォルト設定
if ($IMPORT_MODE -ne "CLEANUP") { $IMPORT_MODE = "REPLACE" }

# 変数設定
$TIMESTAMP = Get-Date -Format "yyyyMMdd_HHmmss"
$DP_FILENAME = "${DUMPFILE_NAME}%U.dmp"
$RDS_LOGFILE_NAME="import_${DUMPFILE_NAME}_rds_${TIMESTAMP}.log"
$BAT_LOGFILE_NAME="import_${DUMPFILE_NAME}_bat_${TIMESTAMP}.log"
$BAT_LOGFILE_PATH="${Env:BAT_LOG_DIR_NAME}\${BAT_LOGFILE_NAME}"
$JOB_NAME="01_exec_imp_${TIMESTAMP}"

# モードによるTABLE_EXISTS_ACTIONの切り替え
# CLEANUPモードなら既にユーザーは消えているので SKIP でも良いが、念のため REPLACE
$TABLE_EXISTS_ACTION="REPLACE"
$INCLUDE_METADATA=1
$SQL_FILE_PATH = "${Env:SOURCE_DIR}\sql\"
$DBMS_OUTPUT="${Env:TEMP_LOG_DIR_NAME}\TEMP_${DUMPFILE_NAME}_${TIMESTAMP}.txt"

# 2.0.1 正常終了処理
function NORMAL {
    if (Test-Path $DBMS_OUTPUT) {
        Write-Output "INFO : RDSログをバッチログに出力します。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
        Get-Content -Path $DBMS_OUTPUT | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
        Remove-Item $DBMS_OUTPUT
    }
    exit 0
}

# 2.1.1 異常終了処理
function ABNORMAL {
    if (Test-Path $DBMS_OUTPUT) {
        Write-Output "INFO : RDSログをバッチログに出力します。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
        Get-Content $DBMS_OUTPUT | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
        Remove-Item $DBMS_OUTPUT
    }
    Write-Output "ERROR : ダンプファイル: ${DUMPFILE_NAME} の JOBSTEP: ${JOB_STEP} で失敗しました。" | Out-File ${Env:TEMP_LOG_DIR_NAME}\ABNORMAL_END_${TAG}_${TIMESTAMP}.txt
    exit 99
}

# 引数チェック (モード追加により5つを期待)
if ($args.Count -lt 4) {
    Write-Output "ERROR : 引数が不足しています。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
    ABNORMAL
}

# 1.3 S3からRDSへダンプファイルをダウンロード
$JOB_STEP="1.3 S3からRDSへダンプファイルをダウンロード"
Write-Output "INFO : S3からRDSへのダウンロードを開始しました。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default

$TEMP_SQL_FILE_PATH = "${SQL_FILE_PATH}s3_download.sql"
$result = & sqlplus -S ${Env:DB_ADMIN_USER}/${Env:DB_ADMIN_PASS}@$Env:LOGIN_INFO @$TEMP_SQL_FILE_PATH $Env:U5_S3EXPIMPBKT $Env:DUMP_DIR_NAME $DUMPFILE_NAME

if ($? -ne 'True') {
    Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default
    Write-Output "ERROR : S3からのダウンロードに失敗しました。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
    ABNORMAL
}
Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default

# 1.3.5 既存ユーザーの削除 (CLEANUPモードのみ実行)
if ($IMPORT_MODE -eq "CLEANUP") {
    $JOB_STEP="1.3.5 既存ユーザーの削除"
    Write-Output "INFO : CLEANUPモードが指定されたため、既存ユーザー ${TABLE_NAME} の削除を開始します。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default

    $TEMP_SQL_FILE_PATH = "${SQL_FILE_PATH}cleanup_users.sql"
    $result = & sqlplus -S ${Env:DB_ADMIN_USER}/${Env:DB_ADMIN_PASS}@$Env:LOGIN_INFO @$TEMP_SQL_FILE_PATH $TABLE_NAME

    if ($? -ne 'True') {
        Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default
        Write-Output "WARNING : ユーザー削除中にエラーが発生しましたが続行します。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
    }
    Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default
} else {
    Write-Output "INFO : REPLACEモードが指定されたため、ユーザー削除をスキップします。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
}

# 1.4 インポート実施
$JOB_STEP="1.4 インポート実施"
Write-Output "INFO : インポートを開始します。 (モード: $IMPORT_MODE, ファイル: $DP_FILENAME)" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default

$TEMP_SQL_FILE_PATH = "${SQL_FILE_PATH}import.sql"
$result = & sqlplus -S ${Env:DB_ADMIN_USER}/${Env:DB_ADMIN_PASS}@$Env:LOGIN_INFO @$TEMP_SQL_FILE_PATH $JOB_NAME $TABLE_NAME $TABLE_EXISTS_ACTION $INCLUDE_METADATA $DP_FILENAME $RDS_LOGFILE_NAME

if ($? -ne 'True') {
    Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default
    Write-Output "ERROR : インポートに失败しました。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
    ABNORMAL
}
Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default

# 1.8 RDS上のファイル削除
$JOB_STEP = "1.8 RDS上のファイル削除"
Write-Output "INFO : RDS上のダンプファイルを削除します。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default

$TEMP_SQL_FILE_PATH = "${SQL_FILE_PATH}fremove_rds_file_2.sql"
$result = & sqlplus -S ${Env:DB_ADMIN_USER}/${Env:DB_ADMIN_PASS}@$Env:LOGIN_INFO @$TEMP_SQL_FILE_PATH $DUMPFILE_NAME $RDS_LOGFILE_NAME

if ($? -ne 'True') {
    Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default
    Write-Output "ERROR : RDS上のファイル削除に失败しました。" | Out-File $BAT_LOGFILE_PATH -Append -Encoding default
    ABNORMAL
}
Write-Output $result | Out-File $DBMS_OUTPUT -Append -Encoding default

# 1.9 正常終了
NORMAL
