@echo off
setlocal

REM 01_exec_import.ps1および01_dmp_import_oratb1.batで使用する環境変数を設定
set "BASE_DIR=%~dp0%..%.."

REM [CHECK] If target DB is oratb4, changing this to oratb4 is recommended for log consistency
set "ORATBX=oratb1"

REM [CHECK] Confirm if this bucket contains the 8 dmp files
set "U5_S3EXPIMPBKT=value-prod-s3-tokyo-tempbucket"

REM [CHECK] Confirm the SID (oratb4) and Hostname
set "LOGIN_INFO=value-prod-restore-db-01.prd.lvcl.jp:1521/oratb4"

REM [CHECK] RDS Administrator Account (for S3 download and Import)
set "DB_ADMIN_USER=admin"
set "DB_ADMIN_PASS=[DB_PASSWORD_HERE]"

set "SOURCE_DIR=%BASE_DIR%\tool\%ORATBX%"
set "DUMP_DIR_NAME=ikou/db_kizon/data/import/%ORATBX%"
set "BAT_LOG_DIR_NAME=%BASE_DIR%\logs\%ORATBX%\import_dmp"
set "TEMP_LOG_DIR_NAME=%BASE_DIR%\temp\%ORATBX%"
set "WINDOWS_DUMP_DIR_NAME=%BASE_DIR%\data\import\%ORATBX%"
set "S3_RDSLOG_DIR_NAME=ikou/db_kizon/logs/import"
set "CONFFILE_DIR_NAME=%BASE_DIR%\conf\%ORATBX%"

set "S3_TRANSFER_INTERVAL_TIMER=5"
REM 0 means no timeout. Recommended for large full-DB dump files.
set "S3_TRANSFER_TIMEOUT_SEC=0"

REM 02_exec_rowcount... (Variables for post-import check scripts)
set schema_oratb1=orausr00
set schema_oratb2=orausr00 orausr20 orausr90
set schema_oratb3=orausr00 orausr20 orausr80 orausr90
set db_oratb1=oratb1.world
set db_oratb2=oratb2.world
set db_oratb3=oratb3.world
set user_info_orausr00=orausr00/orausr00
set user_info_orausr20=orausr20/orausr20
set user_info_orausr80=orausr80/orausr80
set user_info_orausr90=orausr90/orausr90

set host=value-prod-restore-db-01.prd.lvcl.jp
set port=1521
set logoutputpath=%~dp0%..%..\logs

endlocal & (
    set "ORATBX=%ORATBX%"
    set "U5_S3EXPIMPBKT=%U5_S3EXPIMPBKT%"
    set "LOGIN_INFO=%LOGIN_INFO%"
    set "DB_ADMIN_USER=%DB_ADMIN_USER%"
    set "DB_ADMIN_PASS=%DB_ADMIN_PASS%"
    set "SOURCE_DIR=%SOURCE_DIR%"
    set "DUMP_DIR_NAME=%DUMP_DIR_NAME%"
    set "BAT_LOG_DIR_NAME=%BAT_LOG_DIR_NAME%"
    set "TEMP_LOG_DIR_NAME=%TEMP_LOG_DIR_NAME%"
    set "WINDOWS_DUMP_DIR_NAME=%WINDOWS_DUMP_DIR_NAME%"
    set "S3_RDSLOG_DIR_NAME=%S3_RDSLOG_DIR_NAME%"
    set "CONFFILE_DIR_NAME=%CONFFILE_DIR_NAME%"
    set "S3_TRANSFER_INTERVAL_TIMER=%S3_TRANSFER_INTERVAL_TIMER%"
    set "S3_TRANSFER_TIMEOUT_SEC=%S3_TRANSFER_TIMEOUT_SEC%"

    set "schema_oratb1=%schema_oratb1%"
    set "schema_oratb2=%schema_oratb2%"
    set "schema_oratb3=%schema_oratb3%"
    set "db_oratb1=%db_oratb1%"
    set "db_oratb2=%db_oratb2%"
    set "db_oratb3=%db_oratb3%"
    set "user_info_orausr00=%user_info_orausr00%"
    set "user_info_orausr20=%user_info_orausr20%"
    set "user_info_orausr80=%user_info_orausr80%"
    set "user_info_orausr90=%user_info_orausr90%"
    set "host=%host%"
    set "port=%port%"
    set "logoutputpath=%logoutputpath%"
)