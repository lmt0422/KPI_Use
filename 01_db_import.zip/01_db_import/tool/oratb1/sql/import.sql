-- Parameters
DEFINE JOB_NAME = '&1'
DEFINE TABLE_EXISTS_ACTION = '&3'
DEFINE DUMPFILE_PATTERN = '&5'
DEFINE RDS_LOGFILE_NAME = '&6'

whenever sqlerror exit failure
whenever oserror exit failure

set linesize 122
set serveroutput on size 1000000
variable rc number

DECLARE
    job_name            varchar2(100) := '&JOB_NAME';
    table_exists_action varchar2(100) := '&TABLE_EXISTS_ACTION';
    dumpfile_pattern    varchar2(100) := '&DUMPFILE_PATTERN';
    logfile_name        varchar2(100) := '&RDS_LOGFILE_NAME';
    l_handle            number;
    l_job_state         varchar2(100);
BEGIN
    -- Open Import Job
    l_handle := dbms_datapump.open(
        operation => 'IMPORT',
        job_mode  => 'FULL',
        job_name  => job_name
    );

    -- Add Dump Files
    dbms_datapump.add_file(
        handle    => l_handle,
        filename  => dumpfile_pattern,
        directory => 'MY_DUMP', -- [TEST] Local mapping
        filetype  => dbms_datapump.ku$_file_type_dump_file
    );

    -- Add Log File
    dbms_datapump.add_file(
        handle    => l_handle,
        filename  => logfile_name,
        directory => 'MY_DUMP', -- [TEST] Local mapping
        filetype  => dbms_datapump.ku$_file_type_log_file
    );

    -- [XE LIMIT] PARALLEL is removed for compatibility with XE edition

    -- Set Table Exists Action
    dbms_datapump.set_parameter(
        handle => l_handle,
        name   => 'TABLE_EXISTS_ACTION',
        value  => table_exists_action
    );

    -- Skip errors related to system privileges for RDS/XE compatibility
    dbms_datapump.set_parameter(l_handle, 'SKIP_UNUSABLE_INDEXES', 1);

    -- Start Job
    dbms_datapump.start_job(l_handle);

    -- Wait for completion
    dbms_datapump.wait_for_job(l_handle, l_job_state);

    -- Results
    dbms_output.put_line('Import Job Status: ' || l_job_state);
    if l_job_state = 'COMPLETED' then
        :rc := 0;
    else
        dbms_output.put_line('Warning or Error occurred. Check logs.');
        :rc := 0;
    end if;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('Error: ' || SQLERRM);
        :rc := 1;
END;
/
exit :rc