-- パラメータ定義
DEFINE JOB_NAME = '&1'
-- 既存データがある場合の処理 ('REPLACE' : 置換, 'SKIP' : スキップ)
DEFINE TABLE_EXISTS_ACTION = '&3'
-- ファイル名は 'oracle1-%U.dmp' の形式で指定します (01-08を自動認識)
DEFINE DUMPFILE_PATTERN = '&5'
DEFINE RDS_LOGFILE_NAME = '&6'

whenever sqlerror exit failure
whenever oserror exit failure

set linesize 122
set serveroutput on size 1000000
variable rc number

DECLARE
    job_name            varchar2(100) := '&JOB_NAME';
    table_exists_action varchar2(100) := '&TABLE_EXISTS_ACTION';
    dumpfile_pattern    varchar2(100) := '&DUMPFILE_PATTERN'; -- 例: oracle1-%U.dmp
    logfile_name        varchar2(100) := '&RDS_LOGFILE_NAME';
    l_handle            number;
    l_job_state         varchar2(100);
BEGIN
    -- データポンプジョブの作成 (FULLモード)
    l_handle := dbms_datapump.open(
        operation => 'IMPORT',
        job_mode  => 'FULL',
        job_name  => job_name
    );

    -- ダンプファイルをジョブに追加 (%U を使用して 8 ファイルを並列読み込み)
    dbms_datapump.add_file(
        handle    => l_handle,
        filename  => dumpfile_pattern,
        directory => 'DATA_PUMP_DIR',
        filetype  => dbms_datapump.ku$_file_type_dump_file
    );

    -- ログファイルをジョブに追加
    dbms_datapump.add_file(
        handle    => l_handle,
        filename  => logfile_name,
        directory => 'DATA_PUMP_DIR',
        filetype  => dbms_datapump.ku$_file_type_log_file
    );

    -- 並列度の設定 (ファイル数に合わせて 8 に設定)
    dbms_datapump.set_parameter(l_handle, 'PARALLEL', 8);

    -- 既存テーブルの処理アクション設定
    dbms_datapump.set_parameter(
        handle => l_handle,
        name   => 'TABLE_EXISTS_ACTION',
        value  => table_exists_action
    );

    -- 【重要】検証環境への反映のため、本番と表領域名が同じであることを前提とします
    -- もしエラーが出る場合は、ここに metadata_remap を追加してください

    -- RDS制限への対応：システム権限等のエラーをスキップ
    dbms_datapump.set_parameter(l_handle, 'SKIP_UNUSABLE_INDEXES', 1);

    -- 【RDS対応】システムスキーマをインポート対象から除外 (権限エラー回避)
    dbms_datapump.metadata_filter(
        handle => l_handle,
        name   => 'SCHEMA_EXPR',
        value  => 'NOT IN (''RDSADMIN'',''SYS'',''SYSTEM'',''AUDSYS'',''WMSYS'',''DBSNMP'',''XDB'',''ORDDATA'',''CTXSYS'',''MDSYS'',''OLAPSYS'')'
    );

    -- ジョブの開始
    dbms_datapump.start_job(l_handle);

    -- ジョブの完了を待つ
    dbms_datapump.wait_for_job(l_handle, l_job_state);

    -- 結果出力
    dbms_output.put_line('インポート処理完了。ステータス: ' || l_job_state);
    if l_job_state = 'COMPLETED' then
        :rc := 0;
    else
        dbms_output.put_line('警告またはエラーが発生しました。ログを確認してください。');
        :rc := 0;
    end if;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('致命的なエラー：' || SQLERRM);
        :rc := 1;
END;
/
exit :rc