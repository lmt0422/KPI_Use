-- ==========================================================
-- クリーンアップスクリプト (RDS Oracle用)
-- 引数: &1 - 削除対象のスキーマ名
-- ==========================================================
DEFINE SCHEMA_TO_DROP = '&1'

whenever sqlerror continue
whenever oserror exit failure

set linesize 122
set serveroutput on size 1000000

DECLARE
    l_user_exists NUMBER;
    l_username    VARCHAR2(30) := UPPER('&SCHEMA_TO_DROP');
BEGIN
    -- ユーザーが存在するかチェック
    SELECT count(*) INTO l_user_exists FROM all_users WHERE username = l_username;

    IF l_user_exists > 0 THEN
        dbms_output.put_line('INFO: 既存ユーザー ' || l_username || ' を削除します。');
        
        -- RDS専用のユーザー削除プロシージャを実行 (CASCADE相当)
        -- 注意: 接続中のセッションがある場合はエラーになる可能性があります
        BEGIN
            rdsadmin.rdsadmin_util.drop_user(user_name => l_username);
            dbms_output.put_line('INFO: ユーザー ' || l_username || ' の削除が完了しました。');
        EXCEPTION
            WHEN OTHERS THEN
                dbms_output.put_line('ERROR: ユーザー削除中にエラーが発生しました: ' || SQLERRM);
        END;
    ELSE
        dbms_output.put_line('INFO: ユーザー ' || l_username || ' は存在しません。削除をスキップします。');
    END IF;
END;
/

exit;
