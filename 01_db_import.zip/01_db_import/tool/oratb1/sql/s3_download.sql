-- パラメータ定義
-- &1: S3 Bucket Name
-- &2: S3 Directory Path
-- &3: Dump File Prefix (e.g., 'oracle1-')
DEFINE U5_S3EXPIMPBKT = '&1'
DEFINE DUMP_DIR_NAME = '&2'
DEFINE DUMPFILE_PREFIX = '&3'

whenever sqlerror exit failure
whenever oserror exit failure

set linesize 122
set serveroutput on size 1000000
variable rc number

DECLARE
    l_rc NUMBER := 0;
    l_file_name VARCHAR2(100);
BEGIN
    -- 01から08までの分割ファイルをループでダウンロード
    FOR i IN 1..8 LOOP
        -- ファイル名を生成 (例: oracle1-01.dmp)
        l_file_name := '&DUMPFILE_PREFIX' || LPAD(i, 2, '0') || '.dmp';

        dbms_output.put_line('Starting download: ' || l_file_name);

        -- 既存のS3ダウンロード用プロシージャを呼び出し
        -- 注：プロシージャ内部でエラーが発生した際にrcが非0になる想定
        s3_download('&U5_S3EXPIMPBKT', '&DUMP_DIR_NAME', l_file_name, l_rc);

        -- エラーチェック
        IF l_rc <> 0 THEN
            dbms_output.put_line('Error downloading: ' || l_file_name);
            :rc := l_rc;
            RETURN;
        END IF;
    END LOOP;

    :rc := 0;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('Unexpected Error: ' || SQLERRM);
        :rc := 99;
END;
/

-- 戻り値をシェル(PowerShell)に渡す
exit :rc