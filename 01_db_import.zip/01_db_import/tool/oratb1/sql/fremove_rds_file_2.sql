-- パラメータ定義
-- &1: Dump File Prefix (例: 'oracle1-')
-- &2: RDS Log File Name (例: import_oracle1-_rds_20260403.log)
DEFINE DUMPFILE_PREFIX = '&1'
DEFINE RDS_LOGFILE_NAME = '&2'

whenever sqlerror exit failure
whenever oserror exit failure

set linesize 122
set serveroutput on size 1000000

DECLARE
    l_file_name VARCHAR2(100);
BEGIN
    -- 1. 8つの分割ダンプファイルをループで削除
    FOR i IN 1..8 LOOP
        l_file_name := '&DUMPFILE_PREFIX' || LPAD(i, 2, '0') || '.dmp';
        BEGIN
            dbms_output.put_line('Removing dump file: ' || l_file_name);
            UTL_FILE.FREMOVE('DATA_PUMP_DIR', l_file_name);
        EXCEPTION
            WHEN OTHERS THEN
                dbms_output.put_line('Dump file not found (skipped): ' || l_file_name);
        END;
    END LOOP;

    -- 2. RDS上のログファイルを削除
    BEGIN
        dbms_output.put_line('Removing log file: &RDS_LOGFILE_NAME');
        UTL_FILE.FREMOVE('DATA_PUMP_DIR', '&RDS_LOGFILE_NAME');
    EXCEPTION
        WHEN OTHERS THEN
            dbms_output.put_line('Log file not found (skipped): &RDS_LOGFILE_NAME');
    END;
END;
/

exit