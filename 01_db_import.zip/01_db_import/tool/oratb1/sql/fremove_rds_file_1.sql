-- パラメータ定義
-- &1: Dump File Prefix (例: 'oracle1-')
DEFINE DUMPFILE_PREFIX = '&1'

whenever sqlerror exit failure
whenever oserror exit failure

set linesize 122
set serveroutput on size 1000000

DECLARE
    l_file_name VARCHAR2(100);
BEGIN
    -- 01から08までの分割ファイルをループで削除
    FOR i IN 1..8 LOOP
        -- ファイル名を生成 (例: oracle1-01.dmp)
        l_file_name := '&DUMPFILE_PREFIX' || LPAD(i, 2, '0') || '.dmp';

        BEGIN
            dbms_output.put_line('Removing existing file: ' || l_file_name);
            UTL_FILE.FREMOVE('DATA_PUMP_DIR', l_file_name);
        EXCEPTION
            WHEN OTHERS THEN
                -- ファイルが存在しない場合のエラー(ORA-29283など)は無視して次へ
                dbms_output.put_line('File not found or skip: ' || l_file_name);
        END;
    END LOOP;
END;
/

exit